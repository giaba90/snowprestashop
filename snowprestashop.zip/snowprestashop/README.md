#INSTALL#

###Automatic###

This is the easiest method, but it may not work in certain cases. If it does not work, use the manual installation method presented further below.

1. In the modules tab, click on add a new module.

2. If a file of the module exists online, specify its URL in the Module URL field and then click on Download this module.

	2.1 If the file is on your computer, click on Browse to open the dialogue box letting you search your computer, select the file then validate the dialogue box. Finally click on Upload this module.

If the following error message appears:
This means that the PHP extension php_zip is not installed on your serve. You will need to install it or have it installed by your webhost.

3. If the installation is successful, the following message will appear:
The module will then appear in your list of modules under the Module tab.
4. Click on the install button to install the module.

###Manual###

1. Extract the downloaded file (.ZIP)
2. Open the extracted. Copy snowprestashop directory to Prestashop-root-directory/modules via FTP
3. Notice: The directory that you copy: includes a file named snowprestashop.php and does not have any other snowprestashop directory.
4. Go to Back Office -> Modules and click install

Thats all


#Credit#
Developed for Prestashop: by [Gianluca Barranca](www.gianlucabarranca.it)

Tutorial : by [Kirupa](http://www.kirupa.com/html5/the_falling_snow_effect.htm)